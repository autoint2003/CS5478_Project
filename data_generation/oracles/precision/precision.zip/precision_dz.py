"""Inward / outward axial dz correction with flowchart Case A–D shortcuts."""

from __future__ import annotations

from typing import Any

import numpy as np

from data_generation.oracles.precision.contact_modes import classify_contact_mode, make_s1_state
from data_generation.oracles.precision.endpoint_only_axial_roll import (
    DOWN,
    UP,
    choose_roll_sign_for_support,
    gates,
    reference_pad_vector,
    run_roll_phase,
    run_tilt_phase,
)
from data_generation.oracles.precision.finger_supported_vertical import U_OPEN_HAND
from data_generation.oracles.precision.force_slip_control import DT, make_action, sample_state
from data_generation.oracles.precision.orientation_planner import (
    _height_hold_v_hand,
    score_gravity_alignment,
)
from data_generation.oracles.precision.precision_audit import _failure_snapshot
from data_generation.oracles.precision.precision_goals import measure_errors
from data_generation.oracles.precision.precision_slip import (
    _inward_slip_staged,
    _outward_slip_staged,
    settle_hold,
)
from data_generation.oracles.precision.precision_types import (
    FAIL_PREPARATION,
    FAIL_SLIP_CONTACT,
    FAIL_SLIP_WRONG_DIR,
    FAIL_SUPPORT_ROLL,
    FN_HOLD,
    PrecisionConfig,
    ROLL_ANGLE_DEG,
)
from data_generation.oracles.precision.reverse_supported_rotation import HoldModeGrip
from envs.simulation.capture import restore_capture, take_capture
from envs.step_legal import step_legal


def _rate(cfg: PrecisionConfig, name: str, default: float) -> float:
    return float(getattr(cfg, name, default) or default)


def _s1_valid(s1_state: dict | None, sim) -> bool:
    if not s1_state or not s1_state.get("valid"):
        return False
    # Re-verify live contacts; stale flags alone are insufficient.
    live = make_s1_state(sim, roll_sign=s1_state.get("roll_sign"))
    return bool(live.get("valid") and sample_state(sim).get("bilateral"))


def _near_down(sim) -> bool:
    g = gates(sim)
    return bool(g["fingertips_down"] or float(g["alpha_up_deg"]) >= 160.0)


def _establish_s1(env, cur, cfg, y0, e_ref, roll_sign: float, actions: list, phase_prefix: str) -> dict[str, Any]:
    rate_s1 = _rate(cfg, "rate_establish_s1", 0.18)
    if not _near_down(env.sim):
        p0 = run_tilt_phase(
            env, cur, target_dir_w=DOWN, phase=f"{phase_prefix}_prep_down", rate_scale=rate_s1,
            fn_hold=FN_HOLD, ang_tol_deg=6.0, y0_w=y0, e_ref=e_ref, allow_roll=False,
            contact_aware=True, max_time_s=12.0, z_ref_boost=0.05, height_kp=5.0,
        )
        if not p0.get("ok"):
            restore_capture(env, cur["capture"])
            p0 = run_tilt_phase(
                env, cur, target_dir_w=DOWN, phase=f"{phase_prefix}_prep_down_retry", rate_scale=0.10,
                fn_hold=FN_HOLD, ang_tol_deg=8.0, y0_w=y0, e_ref=e_ref, allow_roll=False,
                contact_aware=True, max_time_s=14.0, z_ref_boost=0.07, height_kp=5.5,
            )
        actions += p0.get("actions") or []
        if not (p0.get("ok") and _near_down(env.sim)):
            return {
                "ok": False,
                "reason": p0.get("reason") or "cannot_reach_down_for_S1",
                "capture": p0.get("capture") or cur["capture"],
                "failure_code": FAIL_PREPARATION,
            }
        cur = {"capture": p0["capture"], "ref": cur["ref"]}
    # Soften require_down when near-DOWN but below the strict 175° gate.
    p1 = run_roll_phase(
        env, cur, sign=roll_sign, angle_deg=ROLL_ANGLE_DEG, phase=f"{phase_prefix}_S1",
        rate_scale=rate_s1, fn_hold=FN_HOLD, require_down=bool(gates(env.sim)["fingertips_down"]),
        y0_w=y0, e_ref=e_ref,
    )
    actions += p1.get("actions") or []
    if not p1.get("ok"):
        return {
            "ok": False,
            "reason": p1.get("reason") or "mechanical_support_not_established",
            "capture": p1.get("capture") or cur["capture"],
            "failure_code": FAIL_SUPPORT_ROLL,
        }
    return {"ok": True, "capture": p1["capture"], "s1": make_s1_state(env.sim, roll_sign=roll_sign)}


def _rotate_to(env, cur, target, cfg, y0, e_ref, actions, phase: str, *, protected: bool) -> dict[str, Any]:
    # Large pitch changes under support (horiz↔UP/DOWN) need slow rate + strong height hold.
    alpha0 = float(gates(env.sim)["alpha_up_deg"])
    from_horiz = 60.0 <= alpha0 <= 130.0
    from_up = alpha0 <= 25.0
    if protected and (from_horiz or from_up):
        rate, z_boost, hk = 0.06, 0.10, 6.5
    elif protected:
        rate, z_boost, hk = min(_rate(cfg, "rate_protected_s1", 0.08), 0.16), 0.05, 5.0
    else:
        rate, z_boost, hk = _rate(cfg, "rate_establish_s1", 0.14), 0.05, 5.0
    p = run_tilt_phase(
        env, cur, target_dir_w=target, phase=phase, rate_scale=rate, fn_hold=FN_HOLD,
        ang_tol_deg=6.0, y0_w=y0, e_ref=e_ref, allow_roll=False, contact_aware=True,
        max_time_s=22.0, z_ref_boost=z_boost, height_kp=hk,
    )
    if not p.get("ok"):
        restore_capture(env, cur["capture"])
        p = run_tilt_phase(
            env, cur, target_dir_w=target, phase=f"{phase}_retry", rate_scale=0.04, fn_hold=FN_HOLD,
            ang_tol_deg=8.0, y0_w=y0, e_ref=e_ref, allow_roll=False, contact_aware=True,
            max_time_s=26.0, z_ref_boost=0.15, height_kp=7.0,
        )
    actions += p.get("actions") or []
    return p


def correct_dz_inward(
    env, blob, cfg: PrecisionConfig, *, s1_state: dict | None = None
) -> dict[str, Any]:
    """Case B/C/D inward: S1→UP→DualLoop→S1→DOWN, with skips when already aligned / S1 reused."""
    actions: list = []
    phase_log: list[dict] = []
    restore_capture(env, blob["capture"])
    y0 = reference_pad_vector(env.sim)
    e_ref = np.asarray(sample_state(env.sim)["e_signed_mm"], float)
    cur = {"capture": blob["capture"], "ref": blob["ref"]}
    roll_sign = float(
        (s1_state or {}).get("roll_sign")
        if (s1_state or {}).get("roll_sign") is not None
        else choose_roll_sign_for_support(env.sim)
    )
    branch = "B_full"
    reused_s1 = False

    up_tilt_actions: list = []
    # Case D: already fingertips UP → slide directly
    if gates(env.sim)["fingertips_up"]:
        branch = "D_already_up"
        phase_log.append({"phase": "orientation", "skipped": True, "reason": "already_fingertips_up"})
    else:
        # Case C: reuse valid S1 from dx (or prior)
        if _s1_valid(s1_state, env.sim):
            reused_s1 = True
            branch = "C_reuse_s1"
            phase_log.append({"phase": "S1", "skipped": True, "reused": True, "s1": s1_state})
        else:
            est = _establish_s1(env, cur, cfg, y0, e_ref, roll_sign, actions, "dzIn")
            phase_log.append({"phase": "S1_establish", "ok": est.get("ok"), "reason": est.get("reason")})
            if not est.get("ok"):
                return {
                    "ok": False,
                    "mechanism": "endpoint_only_inward",
                    "branch": branch,
                    "failure_code": est.get("failure_code") or FAIL_SUPPORT_ROLL,
                    "phase": "S1",
                    "reason": est.get("reason"),
                    "actions": actions,
                    "capture": est.get("capture") or cur["capture"],
                    "phase_log": phase_log,
                }
            cur = {"capture": est["capture"], "ref": blob["ref"]}

        # Rotate under support to UP (no dx-style bilateral-friction conversion)
        n_before_up = len(actions)
        p2 = _rotate_to(env, cur, UP, cfg, y0, e_ref, actions, "dzIn_to_UP", protected=True)
        up_tilt_actions = list(actions[n_before_up:])
        phase_log.append({"phase": "to_UP", "ok": p2.get("ok"), "alpha": gates(env.sim)["alpha_up_deg"]})
        if not (p2.get("ok") and gates(env.sim)["fingertips_up"]):
            return {
                "ok": False,
                "mechanism": "endpoint_only_inward",
                "branch": branch,
                "failure_code": FAIL_PREPARATION,
                "phase": "to_UP",
                "reason": p2.get("reason") or "support_lost_or_up_unreachable",
                "actions": actions,
                "capture": p2.get("capture") or cur["capture"],
                "phase_log": phase_log,
                "reused_s1": reused_s1,
            }
        cur = {"capture": p2["capture"], "ref": blob["ref"]}

    restore_capture(env, cur["capture"])
    hold = HoldModeGrip(fn_hold=14.0)
    hold.reset(sample_state(env.sim)["fn_tot"])
    z_ref = float(env.sim.data.xpos[env.sim.ids.object_body][2])
    for _ in range(int(0.4 / DT)):
        st = sample_state(env.sim)
        a_g, _, _ = hold.step(st)
        a = make_action(_height_hold_v_hand(env.sim, z_ref), [0, 0, 0], a_g)
        step_legal(env.sim, a)
        actions.append(a.copy())
    cur = {"capture": take_capture(env), "ref": blob["ref"]}
    e_x0 = float(sample_state(env.sim)["e_signed_mm"][0])
    ez0 = float(sample_state(env.sim)["e_signed_mm"][2])
    slip = _inward_slip_staged(
        env, cur, z_ref, e_x0, milestone_mm=float(cfg.inward_slip_mm), cfg=cfg,
    )
    actions += slip.get("actions") or []
    phase_log.append({
        "phase": "slip_inward",
        "ok": slip.get("ok"),
        "ez0": ez0,
        "disp_along_mm": slip.get("disp_along_mm"),
        "stop_reason": slip.get("stop_reason"),
        "mode": classify_contact_mode(env.sim, sliding="dz")["mode"],
    })
    if not slip.get("ok"):
        return {
            "ok": False,
            "mechanism": "endpoint_only_inward",
            "branch": branch,
            "phase": "slip",
            "reason": slip.get("reason") or slip.get("abort_reason") or slip.get("stop_reason") or "inward_slip_fail",
            "stop_reason": slip.get("stop_reason"),
            "actions": actions,
            "capture": slip.get("capture") or cur["capture"],
            "slip": {k: v for k, v in slip.items() if k not in ("actions", "series", "capture")},
            "phase_log": phase_log,
            "reused_s1": reused_s1,
        }
    cur = {"capture": slip["capture"], "ref": blob["ref"]}
    e_post = np.asarray(slip["e_signed"], float)

    # After UP slide: re-establish S1, then return to DOWN.
    # Prefer time-reversed UP tilt (unwinds wrist) when we executed to_UP from S1/horizontal.
    restore_capture(env, cur["capture"])
    if gates(env.sim)["fingertips_up"] or not _near_down(env.sim):
        rate_s1 = _rate(cfg, "rate_establish_s1", 0.14)
        p_s1 = run_roll_phase(
            env, cur, sign=roll_sign, angle_deg=min(30.0, ROLL_ANGLE_DEG), phase="dzIn_re_S1",
            rate_scale=rate_s1, fn_hold=FN_HOLD, require_down=False, y0_w=y0, e_ref=e_post,
        )
        if p_s1.get("ok"):
            actions += p_s1.get("actions") or []
            cur = {"capture": p_s1["capture"], "ref": blob["ref"]}
            phase_log.append({"phase": "re_S1", "ok": True})
        else:
            phase_log.append({"phase": "re_S1", "ok": False, "reason": p_s1.get("reason")})

        returned = False
        if up_tilt_actions:
            restore_capture(env, cur["capture"])
            n_ok = 0
            for a in reversed(up_tilt_actions):
                aa = np.asarray(a, np.float32).copy()
                aa[:6] *= -1.0
                aa[6] = 1.0
                step_legal(env.sim, aa)
                actions.append(aa.copy())
                n_ok += 1
                if not sample_state(env.sim).get("bilateral"):
                    break
            cur = {"capture": take_capture(env), "ref": blob["ref"]}
            phase_log.append({
                "phase": "return_reverse_UP",
                "ok": bool(sample_state(env.sim).get("bilateral")),
                "n": n_ok,
                "alpha": gates(env.sim)["alpha_up_deg"],
            })
            # Finish to DOWN from the reversed near-horizontal pose
            if sample_state(env.sim).get("bilateral") and not _near_down(env.sim):
                p4 = run_tilt_phase(
                    env, cur, target_dir_w=DOWN, phase="dzIn_return_DOWN",
                    rate_scale=0.08, fn_hold=FN_HOLD, ang_tol_deg=8.0, y0_w=y0, e_ref=e_post,
                    allow_roll=False, contact_aware=True, max_time_s=22.0,
                    z_ref_boost=0.05, height_kp=5.0,
                )
                actions += p4.get("actions") or []
                phase_log.append({"phase": "return_DOWN", "ok": p4.get("ok"), "reason": p4.get("reason")})
                if p4.get("ok"):
                    cur = {"capture": p4["capture"], "ref": blob["ref"]}
                    returned = True
            elif _near_down(env.sim) and sample_state(env.sim).get("bilateral"):
                returned = True
                phase_log.append({"phase": "return_DOWN", "ok": True, "skipped": True, "reason": "reverse_reached_near_down"})

        if not returned:
            p4 = _rotate_to(env, cur, DOWN, cfg, y0, e_post, actions, "dzIn_return_DOWN", protected=True)
            phase_log.append({"phase": "return_DOWN", "ok": p4.get("ok"), "reason": p4.get("reason")})
            if not p4.get("ok"):
                return {
                    "ok": False,
                    "mechanism": "endpoint_only_inward",
                    "branch": branch,
                    "phase": "return_DOWN",
                    "reason": p4.get("reason") or "return_rotation_unsafe",
                    "actions": actions,
                    "capture": p4.get("capture") or cur["capture"],
                    "phase_log": phase_log,
                    "reused_s1": reused_s1,
                }
            cur = {"capture": p4["capture"], "ref": blob["ref"]}

        p5 = run_roll_phase(
            env, cur, sign=-roll_sign, angle_deg=min(30.0, ROLL_ANGLE_DEG), phase="dzIn_unroll",
            rate_scale=_rate(cfg, "rate_friction_support", 0.14), fn_hold=FN_HOLD,
            require_down=bool(gates(env.sim)["fingertips_down"]), y0_w=y0, e_ref=e_post,
        )
        if p5.get("ok"):
            actions += p5.get("actions") or []
            cur = {"capture": p5["capture"], "ref": blob["ref"]}
            phase_log.append({"phase": "unroll", "ok": True})

    restore_capture(env, cur["capture"])
    settle_hold(env, actions, hold_s=0.4)
    return {
        "ok": True,
        "mechanism": "endpoint_only_inward",
        "branch": branch,
        "reused_s1": reused_s1,
        "disp_along_mm": slip.get("disp_along_mm"),
        "disp_total_mm": slip.get("disp_total_mm"),
        "stop_reason": slip.get("stop_reason"),
        "goal_reached": slip.get("goal_reached"),
        "contract": slip.get("contract"),
        "actions": actions,
        "capture": take_capture(env),
        "errors": measure_errors(env.sim),
        "phase_log": phase_log,
        "slip": {k: v for k, v in slip.items() if k not in ("actions", "series", "capture")},
        "fingertips_down": bool(gates(env.sim)["fingertips_down"]),
    }


def correct_dz_outward(
    env, blob, cfg: PrecisionConfig, *, s1_state: dict | None = None
) -> dict[str, Any]:
    """Case A/C/D outward: direct slide when DOWN; else S1-protected rotate to DOWN then slide."""
    actions: list = []
    phase_log: list[dict] = []
    restore_capture(env, blob["capture"])
    y0 = reference_pad_vector(env.sim)
    e0 = np.asarray(sample_state(env.sim)["e_signed_mm"], float)
    cur = {"capture": blob["capture"], "ref": blob["ref"]}
    d_out = np.asarray(U_OPEN_HAND, float)
    roll_sign = float(
        (s1_state or {}).get("roll_sign")
        if (s1_state or {}).get("roll_sign") is not None
        else choose_roll_sign_for_support(env.sim)
    )
    branch = "A_direct_down"
    reused_s1 = False
    skipped_rotation = False

    g0 = gates(env.sim)
    if _near_down(env.sim):
        # Case A / D: no S1 prep, no arm rotation
        skipped_rotation = True
        branch = "A_direct_down" if not s1_state else "D_already_down"
        phase_log.append({
            "phase": "prep",
            "ok": True,
            "skipped": True,
            "reason": "already_fingertips_down_direct_outward",
            "alpha": g0["alpha_up_deg"],
        })
    else:
        # Need rotation to DOWN under support
        if _s1_valid(s1_state, env.sim):
            reused_s1 = True
            branch = "C_reuse_s1_to_down"
            phase_log.append({"phase": "S1", "skipped": True, "reused": True})
        else:
            est = _establish_s1(env, cur, cfg, y0, e0, roll_sign, actions, "dzOut")
            phase_log.append({"phase": "S1_establish", "ok": est.get("ok")})
            if not est.get("ok"):
                return {
                    "ok": False,
                    "mechanism": "dual_loop_outward",
                    "branch": branch,
                    "failure_code": est.get("failure_code") or FAIL_PREPARATION,
                    "phase": "S1",
                    "reason": est.get("reason"),
                    "actions": actions,
                    "capture": est.get("capture") or cur["capture"],
                    "phase_log": phase_log,
                }
            cur = {"capture": est["capture"], "ref": blob["ref"]}
        p_down = _rotate_to(env, cur, DOWN, cfg, y0, e0, actions, "dzOut_to_DOWN", protected=True)
        phase_log.append({"phase": "to_DOWN", "ok": p_down.get("ok")})
        if not (p_down.get("ok") and gates(env.sim)["fingertips_down"]):
            return {
                "ok": False,
                "mechanism": "dual_loop_outward",
                "branch": branch,
                "failure_code": FAIL_PREPARATION,
                "phase": "to_DOWN",
                "reason": p_down.get("reason") or "cannot_align_down_for_outward",
                "actions": actions,
                "capture": p_down.get("capture") or cur["capture"],
                "phase_log": phase_log,
                "reused_s1": reused_s1,
            }
        cur = {"capture": p_down["capture"], "ref": blob["ref"]}

    restore_capture(env, cur["capture"])
    s0 = sample_state(env.sim)
    g_sc = score_gravity_alignment(np.asarray(s0["g_h"], float), d_out)
    phase_log.append({"phase": "gravity_check", "g_score": g_sc, "alpha": gates(env.sim)["alpha_up_deg"]})
    if float(g_sc["useful"]) < 2.5:
        return {
            "ok": False,
            "mechanism": "dual_loop_outward",
            "branch": branch,
            "failure_code": FAIL_PREPARATION,
            "phase": "gravity_projection",
            "reason": "insufficient_outward_gravity",
            "g_score": g_sc,
            "actions": actions,
            "capture": cur["capture"],
            "phase_log": phase_log,
            "skipped_rotation": skipped_rotation,
            "reused_s1": reused_s1,
        }

    # Stable grasp / contact margin before direct slide
    if not s0.get("bilateral") or float(s0.get("fn_tot") or 0) < 4.0:
        return {
            "ok": False,
            "mechanism": "dual_loop_outward",
            "branch": branch,
            "failure_code": FAIL_PREPARATION,
            "phase": "grasp_margin",
            "reason": "unstable_or_insufficient_contact_margin",
            "actions": actions,
            "capture": cur["capture"],
            "phase_log": phase_log,
        }

    e_x0 = float(s0["e_signed_mm"][0])
    ez0 = float(s0["e_signed_mm"][2])
    z_ref = float(env.sim.data.xpos[env.sim.ids.object_body][2])
    milestone = float(cfg.outward_slip_mm)
    slip = _outward_slip_staged(
        env, cur, z_ref=z_ref, e_x0=e_x0, milestone_mm=milestone, cfg=cfg,
    )
    actions += slip.get("actions") or []
    phase_log.append({
        "phase": "slip",
        "ok": slip.get("ok"),
        "ez0": ez0,
        "disp_along_mm": slip.get("disp_along_mm"),
        "stop_reason": slip.get("stop_reason"),
        "goal_reached": slip.get("goal_reached"),
    })
    if not slip.get("ok"):
        return {
            "ok": False,
            "mechanism": "dual_loop_outward",
            "branch": branch,
            "failure_code": slip.get("failure_code") or FAIL_SLIP_CONTACT,
            "phase": "slip",
            "reason": slip.get("reason") or slip.get("abort_reason"),
            "actions": actions,
            "capture": slip.get("capture") or take_capture(env),
            "phase_log": phase_log,
            "skipped_rotation": skipped_rotation,
            "reused_s1": reused_s1,
            "failure": slip.get("failure") or _failure_snapshot(env.sim, phase="slip", code=FAIL_SLIP_CONTACT),
            "slip": {k: v for k, v in slip.items() if k not in ("actions", "series", "capture")},
        }

    restore_capture(env, slip["capture"])
    settle_hold(env, actions, hold_s=0.4)
    err = measure_errors(env.sim)
    if abs(float(err["dx_mm"]) - float(e0[0])) > 5.0 and abs(float(err["dx_mm"])) > 12.0:
        return {
            "ok": False,
            "mechanism": "dual_loop_outward",
            "branch": branch,
            "failure_code": FAIL_SLIP_WRONG_DIR,
            "phase": "coupling_dx",
            "reason": "lateral_regression_after_outward",
            "actions": actions,
            "capture": take_capture(env),
            "phase_log": phase_log,
            "errors": err,
            "skipped_rotation": skipped_rotation,
            "reused_s1": reused_s1,
        }
    phase_log.append({"phase": "settle", "ok": True, "errors": err})
    return {
        "ok": True,
        "mechanism": "dual_loop_outward",
        "branch": branch,
        "skipped_rotation": skipped_rotation,
        "reused_s1": reused_s1,
        "failure_code": None,
        "disp_along_mm": slip.get("disp_along_mm"),
        "disp_total_mm": slip.get("disp_total_mm"),
        "stop_reason": slip.get("stop_reason"),
        "goal_reached": slip.get("goal_reached"),
        "contract": slip.get("contract"),
        "g_score": g_sc,
        "actions": actions,
        "capture": take_capture(env),
        "errors": err,
        "phase_log": phase_log,
        "direction": d_out.tolist(),
        "fingertips_down": bool(gates(env.sim)["fingertips_down"]),
    }
